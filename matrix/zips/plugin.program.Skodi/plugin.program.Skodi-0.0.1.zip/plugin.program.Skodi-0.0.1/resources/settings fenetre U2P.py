xbmc.executebuiltin('Addon.OpenSettings(plugin.video.sendtokodiU2P)') 
