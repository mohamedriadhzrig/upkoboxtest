xbmc.executebuiltin('Dialog.Close(busydialog)')
xbmc.executebuiltin('RunAddon(script.skin.helper.skinbackup)')