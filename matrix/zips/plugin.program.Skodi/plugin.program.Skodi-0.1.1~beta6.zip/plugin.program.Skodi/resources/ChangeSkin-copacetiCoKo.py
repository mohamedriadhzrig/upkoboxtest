xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"lookandfeel.skin" ,"value":"skin.copacetic"}}')
xbmc.executebuiltin('SendClick(11)')
