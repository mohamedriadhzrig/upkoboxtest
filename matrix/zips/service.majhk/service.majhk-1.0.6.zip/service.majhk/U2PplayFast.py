import xbmc

xbmc.sleep(2000)
xbmc.executebuiltin('PlayMedia("plugin://plugin.video.sendtokodiU2P/?action=majhkneww")')