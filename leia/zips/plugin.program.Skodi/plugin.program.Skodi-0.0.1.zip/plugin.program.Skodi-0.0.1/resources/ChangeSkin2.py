#!/usr/bin/python
# -*- coding: utf-8 -*-
import xbmc, xbmcgui

xbmc.executebuiltin('Dialog.Close(busydialog)')
xbmc.executebuiltin("ActivateWindow(interfacesettings)")